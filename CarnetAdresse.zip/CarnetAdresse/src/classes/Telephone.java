package classes;

import java.io.Serializable;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Telephone
 *
 */
@Entity
@Table

public class Telephone implements Serializable {

	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(nullable = false)
	private Integer idt;
	@Column(length = 255)
	private String teldom;
	@Column(length = 255)
	private String telbur;
	@ManyToOne // relation avec la classe Personne
	@JoinColumn(name = "id_Pers") // colonne de liaison avec la classe personne
	private Personne personne; // instance de la personne pour manipuler la classe personne

	public Telephone() {
	
	}

	public Telephone(String teldom, String telbur) {
		this.teldom = teldom;
		this.telbur = telbur;
	}

	public Integer getIdt() {
		return idt;
	}

	public void setIdt(Integer idt) {
		this.idt = idt;
	}

	public String getTeldom() {
		return teldom;
	}

	public void setTeldom(String teldom) {
		this.teldom = teldom;
	}

	public String getTelbur() {
		return telbur;
	}

	public void setTelbur(String telbur) {
		this.telbur = telbur;
	}
	

	public Personne getPersonne() {
		return personne;
	}

	public void setPersonne(Personne personne) {
		this.personne = personne;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
   
	
}
