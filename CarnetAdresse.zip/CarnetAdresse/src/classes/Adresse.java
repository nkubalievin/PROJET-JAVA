package classes;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Adresse
 *
 */
@Entity
@Table

public class Adresse implements Serializable {

	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(nullable = false)
	private Integer ida;
	@Column(length = 255)
	private String adrdom;
	@Column(length = 255)
	private String adrbur;
	
	@ManyToOne // relation avec la classe Personne
	@JoinColumn(name = "id_Pers") // colonne de liaison avec la classe personne
	private Personne personne; // instance de la personne pour manipuler la classe personne
	
	public Adresse() {
		 
	}

	public Adresse(String adrdom, String adrbur) {
		this.adrdom = adrdom;
		this.adrbur = adrbur;
	}

	public Integer getIda() {
		return ida;
	}

	public void setIda(Integer ida) {
		this.ida = ida;
	}

	public Personne getPersonne() {
		return personne;
	}

	public void setPersonne(Personne personne) {
		this.personne = personne;
	}

	public String getAdrdom() {
		return adrdom;
	}

	public void setAdrdom(String adrdom) {
		this.adrdom = adrdom;
	}

	public String getAdrbur() {
		return adrbur;
	}

	public void setAdrbur(String adrbur) {
		this.adrbur = adrbur;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
   
}
