package classes;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Personne
 *
 */
@Entity
@Table
public class Personne implements Serializable {

	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(nullable = false)
	private Integer id;
	@Column(length = 20)
	private String nom;
	@Column(length = 20)
	private String postnom;
	
	@OneToMany(mappedBy="personne", cascade = CascadeType.REMOVE) // relation vers classe telephone avec suppression en cascade
	private List<Telephone> listTelephone = new LinkedList<Telephone>(); // une variable liste de type telephone pour afficher toute la liste
	
	@OneToMany(mappedBy="personne", cascade = CascadeType.REMOVE) // relation vers classe telephone avec suppression en cascade
	private List<Adresse> listAdresse = new LinkedList<Adresse>(); // une variable liste de type telephone pour afficher toute la liste
	
		
	public Personne() {
		
	}
	public Personne(String nom, String postnom) {
		
		this.nom = nom;
		this.postnom = postnom;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPostnom() {
		return postnom;
	}
	public void setPostnom(String postnom) {
		this.postnom = postnom;
	}
	 
	public List<Telephone> getListTelephone() {
		return listTelephone;
	}
	public void setListTelephone(List<Telephone> listTelephone) {
		this.listTelephone = listTelephone;
	}
	public List<Adresse> getListAdresse() {
		return listAdresse;
	}
	public void setListAdresse(List<Adresse> listAdresse) {
		this.listAdresse = listAdresse;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
   
}
