package services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import classes.Personne;

public class PersonneService {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("CarnetAdressePU");
	EntityManager em = emf.createEntityManager();
	
	//recherche d'une personne � partir du nom et prenom
		public Personne getOne(String n, String p){
			Query q = em.createQuery("SELECT p FROM Personne p WHERE p.nom = '" + n + "' AND p.postnom = '" + p + "'");
			try{
			return (Personne)q.getSingleResult();
			}catch(NoResultException nre){
				return null;
			}
		}
		
	//suppression d'un enregistrement avec id en parametre
		public boolean deleteOne(Integer id){
			Personne p = (Personne)em.find(Personne.class, id);
			if(p == null){
				return false;
			}
			else{
				em.getTransaction().begin();
				em.remove(p);
				em.getTransaction().commit();
				return true;
					}
				}	
		
	//permet d'enregistrer dans la base de donn�es
		public Personne saveOne(Personne p){
			em.getTransaction().begin();
			em.persist(p);
			em.getTransaction().commit();
			return p;
		}
		
	//permet de modifier ou updater dans la base de donn�es
		public Personne updateOne(Personne p){
			em.getTransaction().begin();
			em.merge(p);
			em.getTransaction().commit();
			return p;
		}
		
	//renvoie toute la liste de toutes les adresses
		public List<Personne> getAll(){
			return (List<Personne>)em.createQuery("SELECT p FROM Personne p").getResultList();
		}
}
