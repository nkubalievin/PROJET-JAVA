package services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import classes.Adresse;
import classes.Personne;
import classes.Telephone;

public class TelephoneService {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("CarnetAdressePU");
	EntityManager em = emf.createEntityManager();
	
	//renvoie un numero de telephone avec id en parametre
	public Telephone getOne(Integer id){
		return em.find(Telephone.class, id);
	}
	
	//recherche d'un num�ro � partir de numero bureau et domicile
	public Telephone getOne(String bur, String dom){
		Query q = em.createQuery("SELECT t FROM Telephone t WHERE t.telbur = '" + bur + "' AND t.teldom = '" + dom + "'");
		return (Telephone)q.getSingleResult();
	}
	
	//renvoie la liste des numeros enregistr�e avec personne en parametre
	public Telephone getOnetel(Personne p){
		Query q = em.createQuery("SELECT t FROM Telephone t WHERE t.personne.id = '" + p.getId() + "'");
		try{
		return (Telephone)q.getSingleResult();
		}catch(NoResultException nre){
			return null;
		}
	}
	
	
	//suppression d'un enregistrement avec id en parametre
	public boolean deleteOne(Integer id){
		Telephone t = (Telephone)em.find(Telephone.class, id);
		if(t == null){
			return false;
		}
		else{
			em.getTransaction().begin();
			em.remove(t);
			em.getTransaction().commit();
			return true;
		}
	}
	//suppression d'un enregistrement avec le numero de telephone bureau en parametre
	public boolean deleteOneBureau(String numero){
		Query q = em.createQuery("SELECT t FROM Telephone t WHERE t.telbur = '" + numero + "'");
		Telephone t = (Telephone)q.getSingleResult();
		if(t == null){
			return false;
		}
		else{
			em.getTransaction().begin();
			em.remove(t);
			em.getTransaction().commit();
			return true;
		}
	}
	
	
	//suppression d'un enregistrement avec le numero de telephone domicile en parametre
		public boolean deleteOneDomicile(String numero){
			Query q = em.createQuery("SELECT t FROM Telephone t WHERE t.teldom = '" + numero + "'");
			Telephone t = (Telephone)q.getSingleResult();
			if(t == null){
				return false;
			}
			else{
				em.getTransaction().begin();
				em.remove(t);
				em.getTransaction().commit();
				return true;
			}
		}
	
	//permet d'enregistrer dans la base de donn�es
	public Telephone saveOne(Telephone t){
		em.getTransaction().begin();
		em.persist(t);
		em.getTransaction().commit();
		return t;
	}
	
	//permet de modifier ou updater dans la base de donn�es
	public Telephone updateOne(Telephone t){
		em.getTransaction().begin();
		em.merge(t);
		em.getTransaction().commit();
		return t;
	}
	
	//renvoie toute la liste de telephone
	public List<Telephone> getAll(){
		return (List<Telephone>)em.createQuery("SELECT t FROM Telephone t").getResultList();
	}

}
