package services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import classes.Adresse;
import classes.Personne;
import classes.Telephone;

public class AdresseService {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("CarnetAdressePU");
	EntityManager em = emf.createEntityManager();

	//renvoie une adresse de la personne avec id en parametre
	public Adresse getOne(Integer id){
		return em.find(Adresse.class, id);
	}
	
	//renvoie la liste des adresses enregistr�e avec personne en parametre
		public Adresse getOneadr(Personne p){
			Query q = em.createQuery("SELECT adr FROM Adresse adr WHERE adr.personne.id = '" + p.getId() + "'");
			try{
			return (Adresse)q.getSingleResult();
			}catch(NoResultException nre){
				return null;
			}
		}
		
		//recherche d'une adresse � partir du adresse bureau et domicile
				public Adresse getOne(String bur, String dom){
					Query q = em.createQuery("SELECT adr FROM Adresse adr WHERE adr.adrbur = '" + bur + "' AND adr.adrdom = '" + dom + "'");
					return (Adresse)q.getSingleResult();
				}
				
	//suppression d'un enregistrement avec id en parametre
		public boolean deleteOne(Integer id){
			Adresse adr = (Adresse)em.find(Adresse.class, id);
			if(adr == null){
				return false;
			}
			else{
				em.getTransaction().begin();
				em.remove(adr);
				em.getTransaction().commit();
				return true;
			}
		}
		
	//suppression d'un enregistrement avec l'adresse de bureau en parametre
		public boolean deleteOneBureau(String adresse){
			Query q = em.createQuery("SELECT adr FROM Adresse adr WHERE adr.adrbur = '" + adresse + "'");
			Adresse adr = (Adresse)q.getSingleResult();
			if(adr == null){
				return false;
			}
			else{
				em.getTransaction().begin();
				em.remove(adr);
				em.getTransaction().commit();
				return true;
			}
		}
		
	//suppression d'un enregistrement avec l'adresse domicile en parametre
			public boolean deleteOneDomicile(String adresse){
				Query q = em.createQuery("SELECT adr FROM Adresse adr WHERE adr.adrdom = '" + adresse + "'");
				Adresse adr = (Adresse)q.getSingleResult();
				if(adr == null){
					return false;
				}
				else{
					em.getTransaction().begin();
					em.remove(adr);
					em.getTransaction().commit();
					return true;
				}
			}
		
	//permet d'enregistrer dans la base de donn�es
			public Adresse saveOne(Adresse adr){
				em.getTransaction().begin();
				em.persist(adr);
				em.getTransaction().commit();
				return adr;
			}
			
	//permet de modifier ou updater dans la base de donn�es
			public Adresse updateOne(Adresse adr){
				em.getTransaction().begin();
				em.merge(adr);
				em.getTransaction().commit();
				return adr;
			}
			
	//renvoie toute la liste de toutes les adresses
			public List<Adresse> getAll(){
				return (List<Adresse>)em.createQuery("SELECT adr FROM Adresse adr").getResultList();
			}
}
