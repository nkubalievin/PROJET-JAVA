package application;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JTextField;

import java.awt.Font;

import javax.swing.JButton;

import classes.Adresse;
import classes.Personne;
import classes.Telephone;
import services.AdresseService;
import services.PersonneService;
import services.TelephoneService;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;

public class Enregistrement extends JFrame {

	private JPanel contentPane;
	private JTextField txtnom;
	private JTextField txtpost;
	private JTextField txtaddom;
	private JTextField txtadbur;
	private JTextField txtteldom;
	private JTextField txttelbur;

	PersonneService ps = new PersonneService();
	TelephoneService ts = new TelephoneService();
	AdresseService as = new AdresseService();
	Personne p;
	Adresse adr;
	Telephone tel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Enregistrement frame = new Enregistrement();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Enregistrement() {
		setTitle("Carnet d'adresse");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 675, 463);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Nom *");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setBounds(31, 155, 68, 21);
		contentPane.add(lblNewLabel);

		txtnom = new JTextField();
		txtnom.setBounds(109, 155, 165, 21);
		contentPane.add(txtnom);
		txtnom.setColumns(10);

		JLabel lblPrenom = new JLabel("Prenom *");
		lblPrenom.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPrenom.setBounds(31, 190, 68, 19);
		contentPane.add(lblPrenom);

		txtpost = new JTextField();
		txtpost.setBounds(109, 187, 165, 22);
		contentPane.add(txtpost);
		txtpost.setColumns(10);

		JLabel lblAdresseDomicile = new JLabel("Adresse domicile");
		lblAdresseDomicile.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAdresseDomicile.setBounds(31, 220, 112, 24);
		contentPane.add(lblAdresseDomicile);

		JLabel lblNewLabel_2 = new JLabel("Adresse bureau");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2.setBounds(380, 225, 112, 14);
		contentPane.add(lblNewLabel_2);

		txtaddom = new JTextField();
		txtaddom.setBounds(31, 247, 274, 21);
		contentPane.add(txtaddom);
		txtaddom.setColumns(10);

		txtadbur = new JTextField();
		txtadbur.setBounds(380, 245, 269, 24);
		contentPane.add(txtadbur);
		txtadbur.setColumns(10);

		JLabel lblTelephoneDomicile = new JLabel("Telephone domicile");
		lblTelephoneDomicile.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblTelephoneDomicile.setBounds(301, 158, 112, 14);
		contentPane.add(lblTelephoneDomicile);

		txtteldom = new JTextField();
		txtteldom.setBounds(423, 155, 226, 22);
		contentPane.add(txtteldom);
		txtteldom.setColumns(10);

		JLabel lblTelephoneBureau = new JLabel("Telephone bureau");
		lblTelephoneBureau.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblTelephoneBureau.setBounds(301, 189, 112, 21);
		contentPane.add(lblTelephoneBureau);

		txttelbur = new JTextField();
		txttelbur.setBounds(423, 190, 226, 21);
		contentPane.add(txttelbur);
		txttelbur.setColumns(10);

		JLabel lblCarnetDadresseDes = new JLabel(
				"CARNET D'ADRESSE DES CONTACTS");
		lblCarnetDadresseDes.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCarnetDadresseDes.setBounds(133, 57, 310, 34);
		contentPane.add(lblCarnetDadresseDes);

		JButton btnrech = new JButton("Rechercher");
		btnrech.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				p = ps.getOne(txtnom.getText(), txtpost.getText());
				if (p != null) {
					tel = ts.getOnetel(p);
					if (tel != null) {
						txttelbur.setText(tel.getTelbur());
						txtteldom.setText(tel.getTeldom());
					}
					adr = as.getOneadr(p);
					if (adr != null) {
						txtadbur.setText(adr.getAdrbur());
						txtaddom.setText(adr.getAdrdom());
					}
					if ((tel == null || adr == null)) {
						JOptionPane.showMessageDialog(
								null,
								"Pas de numero ou adresse enregistre pour "
										+ txtnom.getText() + " "
										+ txtpost.getText());
					}
				} else {
					JOptionPane.showMessageDialog(null,
							"Aucun contact trouv�, faites un enregistrement");
				}
			}
		});
		btnrech.setBounds(49, 310, 103, 23);
		contentPane.add(btnrech);

		JButton btnmod = new JButton("Modiffier");
		btnmod.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (p != null) {
					p.setNom(txtnom.getText());
					p.setPostnom(txtpost.getText());
					Personne per = ps.updateOne(p);
					Telephone t = new Telephone();
					Adresse a = new Adresse();
					if(tel !=null){
						tel.setTelbur(txttelbur.getText());
						tel.setTeldom(txtteldom.getText());
						t = ts.updateOne(tel);
					}else{
						tel = new Telephone(txtteldom.getText(), txttelbur.getText());
						tel.setPersonne(p);
						t = ts.saveOne(tel);
					}
					if(adr!=null){
						adr.setAdrbur(txtadbur.getText());
						adr.setAdrdom(txtaddom.getText());
						a = as.updateOne(adr);
					}else{
						adr = new Adresse(txtaddom.getText(), txtadbur.getText());
						adr.setPersonne(p);
						a = as.saveOne(adr);
					}
					if (per != null && a != null && t != null) {
						JOptionPane.showMessageDialog(null,
								"Modification effectu�e");
						txtnom.setText("");
						txtpost.setText("");
						txtadbur.setText("");
						txtaddom.setText("");
						txttelbur.setText("");
						txtteldom.setText("");
						txtnom.setFocusable(true);
					} else {
						JOptionPane.showMessageDialog(null,
								"Modification �chou�e");
					}
				}// fin if(p!=null)
				else{
					JOptionPane.showMessageDialog(null,
							"Vous ne pouvez pas modifier un contact inexistant.");
				}
			}
		});
		btnmod.setBounds(158, 310, 89, 23);
		contentPane.add(btnmod);

		JButton btnsup = new JButton("Supprimer");
		btnsup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (ps.deleteOne(p.getId())) {
					JOptionPane
							.showMessageDialog(null, "Suppression effectu�e");
					txtnom.setText("");
					txtpost.setText("");
					txtadbur.setText("");
					txtaddom.setText("");
					txttelbur.setText("");
					txtteldom.setText("");
					txtnom.setFocusable(true);
				} else {
					JOptionPane.showMessageDialog(null, "Suppression �chou�e");
				}
			}
		});
		btnsup.setBounds(250, 310, 112, 23);
		contentPane.add(btnsup);

		JButton btnenr = new JButton("Enregistrer");
		btnenr.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				p.setNom(txtnom.getText());
				p.setPostnom(txtpost.getText());
				adr.setAdrbur(txtadbur.getText());
				adr.setAdrdom(txtaddom.getText());
				tel.setTelbur(txttelbur.getText());
				tel.setTeldom(txtaddom.getText());

				Personne per = ps.saveOne(p);
				Adresse a = as.saveOne(adr);
				Telephone t = ts.saveOne(tel);

				if (per != null && a != null && t != null) {
					JOptionPane.showMessageDialog(null,
							"Enregistrement effectu�");
					txtnom.setText("");
					txtpost.setText("");
					txtadbur.setText("");
					txtaddom.setText("");
					txttelbur.setText("");
					txtteldom.setText("");
					txtnom.setFocusable(true);
				} else {
					JOptionPane
							.showMessageDialog(null, "Enregistrement �chou�");
				}

			}
		});
		btnenr.setBounds(366, 310, 103, 23);
		contentPane.add(btnenr);

		JButton btnaff = new JButton("Afficher carnet");
		btnaff.setBounds(479, 310, 131, 23);
		contentPane.add(btnaff);
	}
}
