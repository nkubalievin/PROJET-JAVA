package application;

import java.util.List;

import classes.Personne;
import services.PersonneService;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonneService ps = new PersonneService();
		
		List<Personne> listPer = ps.getAll();
		
		for(Personne p : listPer){
			System.out.println("Nom: "+p.getNom()+" Prenom: "+p.getPostnom());
		}
		/*Personne p1 = ps.saveOne(p);
		if(p1 != null){
			System.out.println("Enregistrement effectue");
		}else{
			System.out.println("Enregistrement echoue");
		}*/
	}

}
