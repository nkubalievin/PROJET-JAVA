
public class Adresse {

	
	String adrdom;
	String adrbur;
	
	public Adresse(String adrdom, String adrbur) {
		this.adrdom = adrdom;
		this.adrbur = adrbur;
	}

	public Adresse() {
		super();
	}

	public String getAdrdom() {
		return adrdom;
	}

	public void setAdrdom(String adrdom) {
		this.adrdom = adrdom;
	}

	public String getAdrbur() {
		return adrbur;
	}

	public void setAdrbur(String adrbur) {
		this.adrbur = adrbur;
	}
	
		
}
