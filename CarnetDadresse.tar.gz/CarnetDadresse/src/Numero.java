
public class Numero {
	String teldom;
	String telbur;
	
	public Numero(String teldom, String telbur) {
		this.teldom = teldom;
		this.telbur = telbur;
	}

	public Numero() {
		super();
	}

	public String getTeldom() {
		return teldom;
	}

	public void setTeldom(String teldom) {
		this.teldom = teldom;
	}

	public String getTelbur() {
		return telbur;
	}

	public void setTelbur(String telbur) {
		this.telbur = telbur;
	}
	

}
