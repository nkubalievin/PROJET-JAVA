
public class Personne {
	
	String nom;
	String postnom;
	String prenom;
	
	public Personne(String nom, String postnom, String prenom) {
		this.nom = nom;
		this.postnom = postnom;
		this.prenom = prenom;
	}

	public Personne() {
		super();
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPostnom() {
		return postnom;
	}

	public void setPostnom(String postnom) {
		this.postnom = postnom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	
}
